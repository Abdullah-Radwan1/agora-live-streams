import { SimpleAudioExtension } from "./audio-extension";
import { SimpleVideoExtension } from "./video-extension";

export { SimpleAudioExtension, SimpleVideoExtension };
